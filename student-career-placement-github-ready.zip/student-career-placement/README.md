# Student Career & Placement Management System

A full-stack MERN application for students to discover jobs, maintain a career profile, apply for openings, and track application status. Admin users can manage job postings and review applications.

## Tech stack
- React + Vite
- Node.js + Express
- MongoDB + Mongoose
- JWT authentication and bcrypt password hashing
- REST API

## Requirements
- Node.js 18+
- npm
- MongoDB local installation or MongoDB Atlas connection string

## Quick start

1. Create a MongoDB database (local or Atlas).
2. Copy `server/.env.example` to `server/.env` and set `MONGO_URI` and `JWT_SECRET`.
3. Install dependencies from the project root:

   ```bash
   npm install
   npm run install:all
   ```

4. Start the frontend and backend:

   ```bash
   npm run dev
   ```

5. Open the Vite URL shown in the terminal (usually `http://localhost:5173`).
   API runs at `http://localhost:5000`.

## Create an admin
Register a user normally, then promote the user in MongoDB:
```javascript
use student_career_placement
db.users.updateOne({ email: "your-email@example.com" }, { $set: { role: "admin" } })
```
Never expose admin credentials or your database connection string in a public repository.

## API endpoints

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| GET | `/api/health` | Public | Health check |
| POST | `/api/auth/register` | Public | Create student account |
| POST | `/api/auth/login` | Public | Login |
| GET | `/api/auth/me` | Student/Admin | Current user |
| GET | `/api/jobs` | Public | List/search jobs |
| GET | `/api/jobs/:id` | Public | Job details |
| POST | `/api/jobs` | Admin | Create job |
| PUT | `/api/jobs/:id` | Admin | Update job |
| DELETE | `/api/jobs/:id` | Admin | Delete job |
| POST | `/api/applications/:jobId` | Student | Apply to job |
| GET | `/api/applications/mine` | Student | My applications |
| GET | `/api/applications` | Admin | View all applications |
| PATCH | `/api/applications/:id/status` | Admin | Update application status |
| PUT | `/api/profile` | Student | Update profile |

## Deployment overview
- Database: MongoDB Atlas
- Backend: Render or Railway; set `MONGO_URI`, `JWT_SECRET`, `CLIENT_URL`
- Frontend: Vercel; set `VITE_API_URL` to the deployed backend URL plus `/api`
- Add the deployed frontend URL to backend `CLIENT_URL`.

## Important
This is a portfolio/learning starter, not a production-hardened recruitment platform. Before real-world use, add email verification, password reset, rate limiting, audit logs, malware scanning for uploaded files, stronger validation, and tests. Resume upload is not included in this initial version.
