import { useEffect, useMemo, useState } from "react";
import { api, getToken } from "./api";
import { BriefcaseBusiness, GraduationCap, LayoutDashboard, LogOut, Search, ShieldCheck, UserRound, ArrowUpRight, MapPin, Clock3, CheckCircle2, X, Menu, Sparkles, Building2, FileText, Users, Plus, Trash2 } from "lucide-react";

const emptyAuth = { name: "", email: "", password: "" };
const blankJob = { title: "", company: "", location: "India", type: "Full-time", salary: "", description: "", skills: "", eligibility: "" };

export default function App() {
  const [user, setUser] = useState(null);
  const [authMode, setAuthMode] = useState("login");
  const [authForm, setAuthForm] = useState(emptyAuth);
  const [jobs, setJobs] = useState([]);
  const [applications, setApplications] = useState([]);
  const [allApplications, setAllApplications] = useState([]);
  const [page, setPage] = useState("overview");
  const [query, setQuery] = useState("");
  const [type, setType] = useState("");
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [profile, setProfile] = useState({ name:"", phone:"", degree:"", graduationYear:"", skills:"", bio:"" });
  const [jobForm, setJobForm] = useState(blankJob);
  const [showJobForm, setShowJobForm] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);

  useEffect(() => {
    if (!getToken()) return;
    api("/auth/me").then(({ user }) => setUser(user)).catch(() => localStorage.removeItem("scp_token"));
  }, []);
  useEffect(() => { loadJobs(); }, [query, type]);
  useEffect(() => {
    if (!user) return;
    setProfile({ name:user.name || "", phone:user.phone || "", degree:user.degree || "", graduationYear:user.graduationYear || "", skills:(user.skills || []).join(", "), bio:user.bio || "" });
    refreshApplications();
  }, [user]);
  async function loadJobs() {
    try {
      const params = new URLSearchParams();
      if (query.trim()) params.set("q", query.trim());
      if (type) params.set("type", type);
      const { jobs } = await api(`/jobs?${params.toString()}`);
      setJobs(jobs);
    } catch (e) { setError(e.message); }
  }
  async function refreshApplications() {
    try {
      const { applications } = await api(user?.role === "admin" ? "/applications" : "/applications/mine");
      if (user?.role === "admin") setAllApplications(applications); else setApplications(applications);
    } catch (e) { setError(e.message); }
  }
  function flash(message) { setNotice(message); setError(""); window.setTimeout(() => setNotice(""), 3500); }
  function fail(e) { setError(e.message || "Something went wrong."); setNotice(""); }
  async function submitAuth(e) {
    e.preventDefault(); setLoading(true); setError("");
    try {
      const path = authMode === "register" ? "/auth/register" : "/auth/login";
      const { token, user } = await api(path, { method:"POST", body:JSON.stringify(authForm) });
      localStorage.setItem("scp_token", token); setUser(user); setAuthForm(emptyAuth); setPage("overview"); flash(`Welcome${user.name ? `, ${user.name.split(" ")[0]}` : ""}!`);
    } catch (e) { fail(e); } finally { setLoading(false); }
  }
  function logout() { localStorage.removeItem("scp_token"); setUser(null); setApplications([]); setAllApplications([]); setPage("overview"); flash("You have been signed out."); }
  async function apply(job) {
    if (!user) { setAuthMode("login"); setError("Please sign in to apply for jobs."); return; }
    try { await api(`/applications/${job._id}`, { method:"POST", body:JSON.stringify({}) }); await refreshApplications(); flash(`Application sent to ${job.company}.`); }
    catch (e) { fail(e); }
  }
  async function saveProfile(e) {
    e.preventDefault();
    try {
      const { user: updated } = await api("/profile", { method:"PUT", body:JSON.stringify({ ...profile, graduationYear:profile.graduationYear ? Number(profile.graduationYear) : null }) });
      setUser(updated); flash("Your profile has been updated.");
    } catch (e) { fail(e); }
  }
  async function createJob(e) {
    e.preventDefault();
    try {
      await api("/jobs", { method:"POST", body:JSON.stringify({ ...jobForm, skills:jobForm.skills.split(",").map(s=>s.trim()).filter(Boolean) }) });
      setJobForm(blankJob); setShowJobForm(false); await loadJobs(); flash("Job posted successfully.");
    } catch (e) { fail(e); }
  }
  async function deleteJob(job) {
    if (!window.confirm(`Delete ${job.title} at ${job.company}?`)) return;
    try { await api(`/jobs/${job._id}`, { method:"DELETE" }); await loadJobs(); flash("Job deleted."); }
    catch (e) { fail(e); }
  }
  async function updateStatus(id, status) {
    try { await api(`/applications/${id}/status`, { method:"PATCH", body:JSON.stringify({ status }) }); await refreshApplications(); flash("Application status updated."); }
    catch (e) { fail(e); }
  }

  const appliedIds = useMemo(() => new Set(applications.map(a => a.job?._id).filter(Boolean)), [applications]);
  const nav = [
    { id:"overview", label:"Overview", icon:LayoutDashboard },
    { id:"jobs", label:"Explore jobs", icon:BriefcaseBusiness },
    ...(user ? [{ id:"applications", label:user.role === "admin" ? "Applications" : "My applications", icon:FileText }] : []),
    ...(user?.role === "admin" ? [{ id:"manage", label:"Manage jobs", icon:ShieldCheck }] : []),
    ...(user ? [{ id:"profile", label:"My profile", icon:UserRound }] : [])
  ];
  if (!user) return <AuthScreen mode={authMode} setMode={setAuthMode} form={authForm} setForm={setAuthForm} submit={submitAuth} loading={loading} error={error} setError={setError} />;
  return <div className="app-shell">
    <aside className={`sidebar ${mobileMenu ? "open" : ""}`}>
      <div className="brand"><div className="brand-icon"><GraduationCap size={23}/></div><div><strong>CareerLaunch</strong><span>STUDENT PORTAL</span></div></div>
      <div className="workspace-label">WORKSPACE</div>
      <nav>{nav.map(item => <button key={item.id} className={`nav-item ${page===item.id?"active":""}`} onClick={()=>{setPage(item.id);setMobileMenu(false)}}><item.icon size={18}/><span>{item.label}</span>{item.id==="jobs"&&<span className="nav-count">{jobs.length}</span>}</button>)}</nav>
      <div className="sidebar-bottom"><div className="help-card"><div className="help-spark"><Sparkles size={16}/></div><strong>Ready for your next step?</strong><p>Build your profile and discover opportunities that fit your skills.</p><button onClick={()=>setPage("profile")}>Complete profile <ArrowUpRight size={14}/></button></div><div className="sidebar-user"><div className="avatar">{initials(user.name)}</div><div className="user-info"><strong>{user.name}</strong><span>{user.role==="admin"?"Administrator":"Student account"}</span></div><button className="icon-btn" title="Sign out" onClick={logout}><LogOut size={17}/></button></div></div>
    </aside>
    {mobileMenu&&<div className="mobile-scrim" onClick={()=>setMobileMenu(false)} />}
    <main className="main-area">
      <header className="topbar"><button className="mobile-toggle icon-btn" onClick={()=>setMobileMenu(!mobileMenu)}><Menu size={20}/></button><div className="breadcrumbs">Workspace <span>/</span> <strong>{nav.find(n=>n.id===page)?.label || "Overview"}</strong></div><div className="topbar-right"><span className="date-pill"><span className="status-dot"></span> Placement season 2026</span><div className="avatar small">{initials(user.name)}</div></div></header>
      <div className="content">
        {notice&&<div className="alert success"><CheckCircle2 size={17}/>{notice}<button onClick={()=>setNotice("")}><X size={15}/></button></div>}
        {error&&<div className="alert danger"><X size={17}/>{error}<button onClick={()=>setError("")}><X size={15}/></button></div>}
        {page==="overview"&&<Overview user={user} jobs={jobs} applications={user.role==="admin"?allApplications:applications} setPage={setPage} />}
        {page==="jobs"&&<JobsPage jobs={jobs} query={query} setQuery={setQuery} type={type} setType={setType} apply={apply} user={user} appliedIds={appliedIds} onDelete={user.role==="admin"?deleteJob:null}/>}
        {page==="applications"&&<ApplicationsPage items={user.role==="admin"?allApplications:applications} admin={user.role==="admin"} updateStatus={updateStatus}/>}
        {page==="profile"&&<ProfilePage profile={profile} setProfile={setProfile} save={saveProfile} user={user}/>}
        {page==="manage"&&user.role==="admin"&&<ManagePage jobs={jobs} onDelete={deleteJob} show={showJobForm} setShow={setShowJobForm} form={jobForm} setForm={setJobForm} create={createJob}/>}
      </div>
      <footer className="footer"><span>© 2026 CareerLaunch</span><span>Built for the next generation of talent <span className="footer-heart">✦</span></span></footer>
    </main>
  </div>;
}

function AuthScreen({mode,setMode,form,setForm,submit,loading,error,setError}) {
  return <div className="auth-layout"><section className="auth-visual"><div className="auth-brand"><div className="brand-icon"><GraduationCap size={23}/></div><strong>CareerLaunch</strong></div><div className="auth-message"><div className="eyebrow light"><span/> YOUR CAREER STARTS HERE</div><h1>Make your next move <em>your best one.</em></h1><p>One place to discover opportunities, showcase your skills, and move closer to the career you want.</p><div className="visual-stats"><div><strong>01</strong><span>Build your profile</span></div><div><strong>02</strong><span>Discover roles</span></div><div><strong>03</strong><span>Get hired</span></div></div></div><div className="visual-footer">Designed for ambitious students <span>✦</span></div><div className="decor decor-one"></div><div className="decor decor-two"></div></section><section className="auth-panel"><div className="auth-form-wrap"><div className="eyebrow"><span/> STUDENT PLACEMENT PORTAL</div><h2>{mode==="login"?"Welcome back":"Create your account"}</h2><p className="auth-subtitle">{mode==="login"?"Sign in to continue your career journey.":"Start exploring opportunities built for you."}</p>{error&&<div className="alert danger auth-alert">{error}<button onClick={()=>setError("")}><X size={15}/></button></div>}<form onSubmit={submit} className="auth-form">{mode==="register"&&<label>Full name<div className="input-wrap"><UserRound size={17}/><input required minLength="2" placeholder="e.g. Asha Kumar" value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></div></label>}<label>Email address<div className="input-wrap"><span className="input-at">@</span><input required type="email" placeholder="you@example.com" value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/></div></label><label>Password<div className="input-wrap"><span className="input-lock">⌑</span><input required minLength={mode==="register"?8:1} type="password" placeholder={mode==="register"?"At least 8 characters":"Enter your password"} value={form.password} onChange={e=>setForm({...form,password:e.target.value})}/></div></label><button className="btn primary auth-submit" disabled={loading}>{loading?"Please wait…":mode==="login"?"Sign in to account":"Create account"}<ArrowUpRight size={17}/></button></form><div className="auth-switch">{mode==="login"?"New to CareerLaunch?":"Already have an account?"} <button onClick={()=>{setMode(mode==="login"?"register":"login");setError("")}}>{mode==="login"?"Create an account":"Sign in"}</button></div><div className="auth-security"><ShieldCheck size={15}/> Your information is protected with secure authentication.</div></div></section></div>;
}

function Overview({user,jobs,applications,setPage}) {
  const selected=applications.filter(a=>a.status==="Selected").length;
  const pending=applications.filter(a=>["Applied","Under Review"].includes(a.status)).length;
  const recommended=jobs.slice(0,3);
  return <><div className="welcome-row"><div><div className="eyebrow"><span/> YOUR CAREER, IN MOTION</div><h1>{greeting()}, {user.name.split(" ")[0]} <span className="wave">✦</span></h1><p className="muted">Here’s what’s happening with your career journey today.</p></div><button className="btn primary" onClick={()=>setPage("jobs")}><Search size={16}/> Explore opportunities</button></div>
    <div className="hero-banner"><div className="hero-copy"><div className="hero-tag"><Sparkles size={13}/> YOUR FUTURE IS OPEN</div><h2>Small steps today.<br/><em>Big opportunities tomorrow.</em></h2><p>Keep your profile up to date and find roles that match your ambition.</p><button className="btn hero-btn" onClick={()=>setPage("profile")}>Update my profile <ArrowUpRight size={15}/></button></div><div className="hero-art"><div className="art-orbit orbit-a"></div><div className="art-orbit orbit-b"></div><div className="art-card art-card-main"><div className="art-icon"><GraduationCap size={24}/></div><div><strong>Career ready</strong><span>One step at a time</span></div><CheckCircle2 size={20} className="art-check"/></div><div className="art-card art-card-float"><div className="mini-bars"><i/><i/><i/><i/><i/></div><div><strong>Keep growing</strong><span>Skills make a difference</span></div></div><div className="art-star star-one">✦</div><div className="art-star star-two">✧</div></div></div>
    <div className="section-heading"><div><h2>Your overview</h2><p className="muted">A snapshot of your placement progress.</p></div><span className="updated-label">LIVE WORKSPACE</span></div>
    <div className="stats-grid">{(user.role==="admin"?[{label:"Open opportunities",value:jobs.length,icon:BriefcaseBusiness,tone:"violet",hint:"Available listings"},{label:"Applications",value:applications.length,icon:FileText,tone:"blue",hint:"Across all students"},{label:"Selected",value:selected,icon:CheckCircle2,tone:"green",hint:"Successful outcomes"},{label:"Under review",value:pending,icon:Clock3,tone:"amber",hint:"Awaiting decisions"}]:[{label:"Available jobs",value:jobs.length,icon:BriefcaseBusiness,tone:"violet",hint:"Explore your options"},{label:"Applications sent",value:applications.length,icon:FileText,tone:"blue",hint:"Your active journey"},{label:"Under review",value:pending,icon:Clock3,tone:"amber",hint:"Moving forward"},{label:"Selected",value:selected,icon:CheckCircle2,tone:"green",hint:"Offers received"}]).map(s=><div className="stat-card" key={s.label}><div className={`stat-icon ${s.tone}`}><s.icon size={19}/></div><span className="stat-label">{s.label}</span><strong className="stat-value">{s.value}</strong><span className="stat-hint">{s.hint}</span></div>)}</div>
    <div className="section-heading jobs-heading"><div><h2>{user.role==="admin"?"Recently posted opportunities":"Fresh opportunities"}</h2><p className="muted">Explore roles where you can make an impact.</p></div><button className="text-link" onClick={()=>setPage("jobs")}>View all jobs <ArrowUpRight size={15}/></button></div>
    <div className="job-grid compact">{recommended.length?recommended.map(job=><JobCard key={job._id} job={job} onApply={()=>setPage("jobs")} compact/>):<EmptyState title="No opportunities yet" text="Check back soon, or ask an administrator to publish the first listing."/>}</div>
    <div className="bottom-tip"><div className="tip-icon"><Sparkles size={18}/></div><div><strong>Your next opportunity could be one click away.</strong><p>Keep your skills current and check application statuses regularly.</p></div><button className="text-link" onClick={()=>setPage("applications")}>Track progress <ArrowUpRight size={15}/></button></div>
  </>;
}
function JobsPage({jobs,query,setQuery,type,setType,apply,user,appliedIds,onDelete}) {
  return <><PageIntro eyebrow="OPPORTUNITY BOARD" title="Find your next opportunity" subtitle="Explore roles, discover companies, and take the next step in your career."/><div className="job-filters"><div className="search-box"><Search size={18}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search by role, company, or skill…"/>{query&&<button onClick={()=>setQuery("")}><X size={15}/></button>}</div><select value={type} onChange={e=>setType(e.target.value)}><option value="">All employment types</option><option>Full-time</option><option>Internship</option><option>Contract</option></select><span className="result-count">{jobs.length} {jobs.length===1?"opportunity":"opportunities"}</span></div><div className="job-grid">{jobs.length?jobs.map(job=><JobCard key={job._id} job={job} onApply={()=>apply(job)} applied={appliedIds.has(job._id)} admin={user?.role==="admin"} onDelete={onDelete}/>):<EmptyState title="No matching jobs" text="Try another keyword or change your employment-type filter."/>}</div></>;
}
function JobCard({job,onApply,applied,admin,onDelete,compact=false}) {
  return <article className={`job-card ${compact?"compact-card":""}`}><div className="job-card-top"><div className="company-mark">{(job.company||"C").slice(0,1).toUpperCase()}</div><div className="job-company"><strong>{job.company}</strong><span>{job.location||"India"}</span></div><button className="icon-btn external-icon" title="Opportunity"><ArrowUpRight size={17}/></button></div><h3>{job.title}</h3><div className="job-meta"><span><BriefcaseBusiness size={14}/>{job.type||"Full-time"}</span><span><MapPin size={14}/>{job.location||"India"}</span></div>{!compact&&<p className="job-description">{job.description}</p>}<div className="skill-tags">{(job.skills||[]).slice(0,compact?3:5).map(skill=><span key={skill}>{skill}</span>)}{!job.skills?.length&&<span>Entry level</span>}</div><div className="job-card-bottom"><div className="salary"><strong>{job.salary||"Salary not disclosed"}</strong><span>Compensation</span></div>{admin?<button className="btn danger-outline small-btn" onClick={()=>onDelete?.(job)}><Trash2 size={14}/> Delete</button>:<button className={`btn ${applied?"applied-btn":"outline"} small-btn`} onClick={onApply} disabled={applied}>{applied?<><CheckCircle2 size={14}/> Applied</>:<>Apply now <ArrowUpRight size={14}/></>}</button>}</div></article>;
}
function ApplicationsPage({items,admin,updateStatus}) {
  return <><PageIntro eyebrow="APPLICATION TRACKER" title={admin?"Manage student applications":"Your applications"} subtitle={admin?"Review candidates and keep application decisions moving.":"Keep track of every opportunity you have applied for."}/><div className="table-card">{items.length?<div className="table-scroll"><table><thead><tr>{admin&&<th>Student</th>}<th>Position</th><th>Company</th><th>Applied on</th><th>Status</th>{admin&&<th>Update</th>}</tr></thead><tbody>{items.map(app=><tr key={app._id}>{admin&&<td><div className="table-person"><div className="avatar tiny">{initials(app.student?.name)}</div><div><strong>{app.student?.name||"Student"}</strong><span>{app.student?.email}</span></div></div></td>}<td><strong>{app.job?.title||"Deleted job"}</strong></td><td>{app.job?.company||"—"}</td><td>{new Date(app.createdAt).toLocaleDateString()}</td><td><StatusPill status={app.status}/></td>{admin&&<td><select className="status-select" value={app.status} onChange={e=>updateStatus(app._id,e.target.value)}>{["Applied","Under Review","Shortlisted","Rejected","Selected"].map(s=><option key={s}>{s}</option>)}</select></td>}</tr>)}</tbody></table></div>:<EmptyState title="No applications yet" text={admin?"Student applications will appear here when candidates apply.":"When you apply to a job, its status will show up here."}/>}</div></>;
}
function ProfilePage({profile,setProfile,save,user}) {
  return <><PageIntro eyebrow="YOUR PROFESSIONAL IDENTITY" title="My profile" subtitle="Help employers understand your strengths, background, and goals."/><div className="profile-layout"><div className="profile-summary"><div className="profile-cover"></div><div className="profile-avatar">{initials(user.name)}</div><h2>{user.name}</h2><p>{user.degree||"Add your degree or specialization"}</p><div className="profile-email">{user.email}</div><div className="profile-completion"><div><span>Profile details</span><strong>{[profile.name,profile.degree,profile.skills,profile.bio].filter(Boolean).length}/4</strong></div><div className="progress-track"><span style={{width:`${[profile.name,profile.degree,profile.skills,profile.bio].filter(Boolean).length/4*100}%`}}/></div><small>A complete profile helps you present your skills clearly.</small></div></div><form className="form-card profile-form" onSubmit={save}><div className="form-title"><div><h2>Personal details</h2><p>Keep your career information up to date.</p></div><UserRound size={20}/></div><div className="form-grid"><label>Full name<input required value={profile.name} onChange={e=>setProfile({...profile,name:e.target.value})}/></label><label>Email address<input disabled value={user.email}/></label><label>Phone number<input value={profile.phone} onChange={e=>setProfile({...profile,phone:e.target.value})} placeholder="+91 98765 43210"/></label><label>Degree / specialization<input value={profile.degree} onChange={e=>setProfile({...profile,degree:e.target.value})} placeholder="B.E. Computer Science"/></label><label>Graduation year<input type="number" min="2000" max="2100" value={profile.graduationYear} onChange={e=>setProfile({...profile,graduationYear:e.target.value})} placeholder="2027"/></label><label className="span-two">Skills <span className="field-hint">Separate skills with commas</span><input value={profile.skills} onChange={e=>setProfile({...profile,skills:e.target.value})} placeholder="React, JavaScript, SQL, teamwork"/></label><label className="span-two">Professional summary<textarea rows="4" maxLength="500" value={profile.bio} onChange={e=>setProfile({...profile,bio:e.target.value})} placeholder="Share your interests, strengths, and career goals…"/></label></div><div className="form-actions"><span>Changes are saved to your account.</span><button className="btn primary" type="submit">Save changes <CheckCircle2 size={16}/></button></div></form></div></>;
}
function ManagePage({jobs,onDelete,show,setShow,form,setForm,create}) {
  return <><PageIntro eyebrow="ADMINISTRATION" title="Manage opportunities" subtitle="Publish new roles and keep job listings up to date."/><div className="manage-toolbar"><div><strong>{jobs.length} published {jobs.length===1?"role":"roles"}</strong><p>Visible to registered students and visitors.</p></div><button className="btn primary" onClick={()=>setShow(!show)}>{show?<X size={16}/>:<Plus size={17}/>} {show?"Cancel":"Post a job"}</button></div>{show&&<form className="form-card create-job-form" onSubmit={create}><div className="form-grid"><label>Job title<input required value={form.title} onChange={e=>setForm({...form,title:e.target.value})} placeholder="Frontend Developer"/></label><label>Company<input required value={form.company} onChange={e=>setForm({...form,company:e.target.value})} placeholder="Company name"/></label><label>Location<input value={form.location} onChange={e=>setForm({...form,location:e.target.value})}/></label><label>Employment type<select value={form.type} onChange={e=>setForm({...form,type:e.target.value})}><option>Full-time</option><option>Internship</option><option>Contract</option></select></label><label>Salary / stipend<input value={form.salary} onChange={e=>setForm({...form,salary:e.target.value})} placeholder="₹4–6 LPA"/></label><label>Required skills <span className="field-hint">Comma separated</span><input value={form.skills} onChange={e=>setForm({...form,skills:e.target.value})} placeholder="React, Node.js"/></label><label className="span-two">Description<textarea required rows="4" value={form.description} onChange={e=>setForm({...form,description:e.target.value})} placeholder="Describe the role, responsibilities, and requirements…"/></label><label className="span-two">Eligibility<input value={form.eligibility} onChange={e=>setForm({...form,eligibility:e.target.value})} placeholder="e.g. 2027 graduates, no active backlogs"/></label></div><div className="form-actions"><span>Required fields: title, company, description.</span><button className="btn primary">Publish opportunity <ArrowUpRight size={16}/></button></div></form>}<div className="manage-list">{jobs.map(job=><div className="manage-row" key={job._id}><div className="company-mark">{job.company.slice(0,1).toUpperCase()}</div><div className="manage-job-info"><strong>{job.title}</strong><span>{job.company} · {job.location}</span></div><span className="type-chip">{job.type}</span><button className="btn danger-outline small-btn" onClick={()=>onDelete(job)}><Trash2 size={14}/> Delete</button></div>)}</div></>;
}
function PageIntro({eyebrow,title,subtitle}) { return <div className="page-intro"><div className="eyebrow"><span/>{eyebrow}</div><h1>{title}</h1><p>{subtitle}</p></div>; }
function StatusPill({status}) { const c=status==="Selected"?"green":status==="Rejected"?"red":status==="Shortlisted"?"violet":status==="Under Review"?"amber":"blue";return <span className={`status-pill ${c}`}><i/>{status}</span>; }
function EmptyState({title,text}) { return <div className="empty-state"><div className="empty-icon"><Building2 size={22}/></div><strong>{title}</strong><p>{text}</p></div>; }
function initials(name="Student") { return name.split(/\s+/).filter(Boolean).slice(0,2).map(n=>n[0]).join("").toUpperCase()||"ST"; }
function greeting() { const h=new Date().getHours();return h<12?"Good morning":h<17?"Good afternoon":"Good evening"; }
