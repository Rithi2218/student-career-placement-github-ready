import mongoose from "mongoose";

const jobSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true },
  company: { type: String, required: true, trim: true },
  location: { type: String, default: "India" },
  type: { type: String, enum: ["Full-time", "Internship", "Contract"], default: "Full-time" },
  description: { type: String, required: true },
  skills: { type: [String], default: [] },
  eligibility: { type: String, default: "Open to eligible applicants" },
  salary: { type: String, default: "Not disclosed" },
  deadline: { type: Date, default: null },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" }
}, { timestamps: true });

export default mongoose.model("Job", jobSchema);