import mongoose from "mongoose";

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 80 },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  passwordHash: { type: String, required: true },
  role: { type: String, enum: ["student", "admin"], default: "student" },
  phone: { type: String, default: "" },
  degree: { type: String, default: "" },
  graduationYear: { type: Number, default: null },
  skills: { type: [String], default: [] },
  bio: { type: String, default: "", maxlength: 500 },
  createdAt: { type: Date, default: Date.now }
}, { timestamps: true });

export default mongoose.model("User", userSchema);