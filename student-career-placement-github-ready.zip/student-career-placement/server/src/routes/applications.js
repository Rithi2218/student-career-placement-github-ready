import { Router } from "express";
import Application from "../models/Application.js";
import Job from "../models/Job.js";
import { protect, adminOnly } from "../middleware/auth.js";

const router = Router();
router.post("/:jobId", protect, async (req, res, next) => {
  try {
    if (req.user.role !== "student") return res.status(403).json({ message: "Only student accounts can apply." });
    const job = await Job.findById(req.params.jobId);
    if (!job) return res.status(404).json({ message: "Job not found." });
    const application = await Application.create({ student: req.user._id, job: job._id, coverNote: req.body.coverNote || "" });
    res.status(201).json({ application, message: "Application submitted successfully." });
  } catch (err) {
    if (err.code === 11000) return res.status(409).json({ message: "You have already applied for this job." });
    next(err);
  }
});
router.get("/mine", protect, async (req, res, next) => {
  try {
    const applications = await Application.find({ student: req.user._id }).populate("job").sort({ createdAt: -1 });
    res.json({ applications });
  } catch (err) { next(err); }
});
router.get("/", protect, adminOnly, async (_req, res, next) => {
  try {
    const applications = await Application.find().populate("student", "name email degree graduationYear skills").populate("job", "title company").sort({ createdAt: -1 });
    res.json({ applications });
  } catch (err) { next(err); }
});
router.patch("/:id/status", protect, adminOnly, async (req, res, next) => {
  try {
    const allowed = ["Applied", "Under Review", "Shortlisted", "Rejected", "Selected"];
    if (!allowed.includes(req.body.status)) return res.status(400).json({ message: "Invalid application status." });
    const application = await Application.findByIdAndUpdate(req.params.id, { status: req.body.status }, { new: true })
      .populate("student", "name email").populate("job", "title company");
    if (!application) return res.status(404).json({ message: "Application not found." });
    res.json({ application });
  } catch (err) { next(err); }
});
export default router;