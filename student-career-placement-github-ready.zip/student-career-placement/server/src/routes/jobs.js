import { Router } from "express";
import Job from "../models/Job.js";
import { protect, adminOnly } from "../middleware/auth.js";

const router = Router();
router.get("/", async (req, res, next) => {
  try {
    const { q = "", type = "", location = "" } = req.query;
    const filter = {};
    if (q) filter.$or = [{ title: new RegExp(escapeRegex(q), "i") }, { company: new RegExp(escapeRegex(q), "i") }, { skills: new RegExp(escapeRegex(q), "i") }];
    if (type) filter.type = type;
    if (location) filter.location = new RegExp(escapeRegex(location), "i");
    const jobs = await Job.find(filter).sort({ createdAt: -1 }).limit(100);
    res.json({ jobs });
  } catch (err) { next(err); }
});
router.get("/:id", async (req, res, next) => {
  try {
    const job = await Job.findById(req.params.id);
    if (!job) return res.status(404).json({ message: "Job not found." });
    res.json({ job });
  } catch (err) { next(err); }
});
router.post("/", protect, adminOnly, async (req, res, next) => {
  try {
    const { title, company, description } = req.body;
    if (!title || !company || !description) return res.status(400).json({ message: "Title, company and description are required." });
    const job = await Job.create({ ...req.body, createdBy: req.user._id });
    res.status(201).json({ job });
  } catch (err) { next(err); }
});
router.put("/:id", protect, adminOnly, async (req, res, next) => {
  try {
    const job = await Job.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!job) return res.status(404).json({ message: "Job not found." });
    res.json({ job });
  } catch (err) { next(err); }
});
router.delete("/:id", protect, adminOnly, async (req, res, next) => {
  try {
    const job = await Job.findByIdAndDelete(req.params.id);
    if (!job) return res.status(404).json({ message: "Job not found." });
    res.json({ message: "Job deleted." });
  } catch (err) { next(err); }
});
function escapeRegex(value) { return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }
export default router;