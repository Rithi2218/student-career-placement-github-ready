import { Router } from "express";
import User from "../models/User.js";
import { protect } from "../middleware/auth.js";

const router = Router();
router.put("/", protect, async (req, res, next) => {
  try {
    const allowed = ["name", "phone", "degree", "graduationYear", "skills", "bio"];
    const update = {};
    for (const key of allowed) if (req.body[key] !== undefined) update[key] = req.body[key];
    if (typeof update.skills === "string") update.skills = update.skills.split(",").map(s => s.trim()).filter(Boolean);
    const user = await User.findByIdAndUpdate(req.user._id, update, { new: true, runValidators: true }).select("-passwordHash");
    res.json({ user });
  } catch (err) { next(err); }
});
export default router;